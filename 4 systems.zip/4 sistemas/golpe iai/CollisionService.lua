-- every Combatant goes in "Combatants". while dashing (iai) the attacker swaps to "Dashing"
-- which doesn't collide with characters, so they go through the target instead of
-- crashing into it and flying off. groups are set up in Studio (Model > Collision Groups)

local CollectionService = game:GetService("CollectionService")

local CollisionService = {}

local DEFAULT = "Combatants"
local DASHING = "Dashing"

local dashToken = setmetatable({}, { __mode = "k" })

local function setGroup(model, group)
	for _, d in model:GetDescendants() do
		if d:IsA("BasePart") then
			d.CollisionGroup = group
		end
	end
end

local function track(model)
	if not model:IsA("Model") then
		return
	end
	setGroup(model, DEFAULT)
	-- tools/accessories get added later
	model.DescendantAdded:Connect(function(d)
		if d:IsA("BasePart") then
			d.CollisionGroup = dashToken[model] and DASHING or DEFAULT
		end
	end)
end

function CollisionService.dash(model: Model, seconds: number)
	-- token so an older dash ending doesn't reset a newer one
	local id = {}
	dashToken[model] = id
	setGroup(model, DASHING)
	task.delay(seconds, function()
		if dashToken[model] == id then
			dashToken[model] = nil
			setGroup(model, DEFAULT)
		end
	end)
end

function CollisionService.start()
	for _, m in CollectionService:GetTagged("Combatant") do
		track(m)
	end
	CollectionService:GetInstanceAddedSignal("Combatant"):Connect(track)
end

return CollisionService
