-- Iai (E): sheathe, charge, release -> dash straight through whoever is in front and
-- the cut lands a moment later (CutDelay). breaks guard, more charge = further + more dmg
--
-- players move themselves on the client (prediction), here we only validate and
-- work out who got cut. for npcs the server also does the dash

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CollectionService = game:GetService("CollectionService")

local Combat = ReplicatedStorage:WaitForChild("Combat")
local CombatConfig = require(Combat:WaitForChild("CombatConfig"))
local CombatFX = Combat:WaitForChild("Remotes"):WaitForChild("CombatFX")
local IaiPath = require(Combat:WaitForChild("IaiPath"))
local DashMotion = require(Combat:WaitForChild("DashMotion"))

local CollisionService = require(script.Parent:WaitForChild("CollisionService"))
local ComboService = require(script.Parent:WaitForChild("ComboService"))
local CombatResolver = require(script.Parent:WaitForChild("CombatResolver"))
local Signal = require(script.Parent:WaitForChild("Signal"))

local IaiService = {}

-- (attacker, from, to, cutDelay) - lets the sensei react to the player's iai
IaiService.Released = Signal.new()

local CFG = CombatConfig.Iai
local TARGET_RADIUS = 1.5
-- extra room checked when the cut actually lands. dash out of the line before that and you dodge it
local DODGE_GRACE = 3

local charging = {} -- [model] = time it started charging
local readyAt = setmetatable({}, { __mode = "k" })

local function now()
	return workspace:GetServerTimeNow()
end

local function alive(model)
	local hum = model and model:FindFirstChildOfClass("Humanoid")
	return hum ~= nil and hum.Health > 0
end

local function setCharging(model, on)
	model:SetAttribute("IaiCharging", on or nil)
	local hum = model:FindFirstChildOfClass("Humanoid")
	if not hum then
		return
	end
	if on then
		model:SetAttribute("BaseWalkSpeed", model:GetAttribute("BaseWalkSpeed") or hum.WalkSpeed)
		hum.WalkSpeed = CFG.ChargeWalkSpeed
	else
		hum.WalkSpeed = model:GetAttribute("BaseWalkSpeed") or 16
	end
end

-- distance from a model to the from->to segment, flattened
local function nearPath(model, from, to, grace)
	local root = model:FindFirstChild("HumanoidRootPart")
	if not root then
		return false
	end
	local seg = to - from
	local len = seg.Magnitude
	local dir = len > 0 and seg / len or Vector3.zero
	local p = root.Position
	local closest = from + dir * math.clamp((p - from):Dot(dir), 0, len)
	local sideways = Vector3.new(p.X - closest.X, 0, p.Z - closest.Z).Magnitude
	return sideways <= CFG.Width + TARGET_RADIUS + grace and math.abs(p.Y - closest.Y) <= 6
end

local function targetsAlong(attacker, from, to, grace)
	local list = {}
	for _, model in CollectionService:GetTagged("Combatant") do
		if model ~= attacker and alive(model) and nearPath(model, from, to, grace) then
			table.insert(list, model)
		end
	end
	return list
end

function IaiService.isReady(model: Model): boolean
	return now() >= (readyAt[model] or 0)
end

function IaiService.isCharging(model: Model): boolean
	return charging[model] ~= nil
end

function IaiService.cancel(model: Model)
	if charging[model] then
		charging[model] = nil
		setCharging(model, false)
	end
end

function IaiService.begin(char: Model?, plr: Player?): boolean
	if not char or charging[char] then
		return false
	end
	if not ComboService.canAttack(char) or ComboService.isBusy(char) or now() < (readyAt[char] or 0) then
		return false
	end
	local started = now()
	charging[char] = started
	setCharging(char, true)

	-- held too long -> it goes off by itself
	task.delay(CFG.MaxHold, function()
		if charging[char] == started then
			IaiService.unleash(char, plr)
		end
	end)
	return true
end

function IaiService.start(plr: Player)
	IaiService.begin(plr.Character, plr)
end

function IaiService.release(plr: Player)
	if plr.Character then
		IaiService.unleash(plr.Character, plr)
	end
end

function IaiService.unleash(char: Model, plr: Player?)
	local started = charging[char]
	if not started then
		return
	end
	charging[char] = nil
	setCharging(char, false)

	local root = char:FindFirstChild("HumanoidRootPart")
	if not root or not alive(char) or not char:FindFirstChild("Katana") then
		return
	end
	if (char:GetAttribute("StunnedUntil") or 0) > now() then
		return -- got hit while charging, iai is lost
	end
	readyAt[char] = now() + CFG.Cooldown

	local charge = math.clamp((now() - started) / CFG.FullCharge, 0, 1)
	local look = root.CFrame.LookVector
	local dir = Vector3.new(look.X, 0, look.Z).Unit
	local from = root.Position
	local dist = IaiPath.distance(char, from, dir, charge)
	local to = from + dir * dist

	CollisionService.dash(char, CFG.DashTime + 0.25) -- goes through people instead of bonking into them
	--warn("iai", char.Name, math.floor(charge * 100), dist)

	-- npc: we have to move the body ourselves. players already did it on their client
	if not plr then
		DashMotion.run(root, dir, dist / CFG.DashTime, CFG.DashTime, 0)
	end

	ComboService.setBusy(char, CFG.DashTime + CFG.CutDelay)
	CombatFX:FireAllClients("Iai", { attacker = char, from = from, to = to, charge = charge })
	IaiService.Released:Fire(char, from, to, CFG.DashTime + CFG.CutDelay)

	local targets = targetsAlong(char, from, to, CombatConfig.M1.LatencyGrace)
	local dmg = (CFG.Damage + (CFG.FullDamage - CFG.Damage) * charge) * (char:GetAttribute("DamageScale") or 1)

	task.delay(CFG.DashTime + CFG.CutDelay, function()
		local cut = {}
		for _, target in targets do
			-- has to still be on the line when the cut lands
			if alive(target) and char.Parent and nearPath(target, from, to, CombatConfig.M1.LatencyGrace + DODGE_GRACE) then
				local result = CombatResolver.hit(char, plr, target, {
					kind = "Iai",
					origin = from,
					breaksGuard = true,
					damage = dmg,
					stagger = true,
					knockback = CFG.Knockback,
					lift = CFG.Lift,
					stun = CFG.Stun,
				})
				if result ~= "parry" then
					table.insert(cut, target)
				end
			end
		end
		CombatFX:FireAllClients("IaiCut", { attacker = char, targets = cut, dir = dir })
	end)
end

Players.PlayerRemoving:Connect(function(plr)
	if plr.Character then
		charging[plr.Character] = nil
	end
end)

return IaiService
