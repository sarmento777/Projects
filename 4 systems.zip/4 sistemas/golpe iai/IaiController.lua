-- hold E: sword goes back in the sheath and charges (bar on the slot + aura)
-- let go: dash forward and cut. the dash itself is done here since the client owns
-- its character, the server checks it and decides who actually got cut

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local ContextActionService = game:GetService("ContextActionService")

local Combat = script.Parent.Parent
local CombatRequest = Combat:WaitForChild("Remotes"):WaitForChild("CombatRequest")
local DrawState = require(Combat:WaitForChild("DrawState"))
local IaiPath = require(Combat:WaitForChild("IaiPath"))
local DashMotion = require(Combat:WaitForChild("DashMotion"))

local Client = script.Parent
local AnimLibrary = require(Client:WaitForChild("AnimLibrary"))
local AimFacing = require(Client:WaitForChild("AimFacing"))
local BladeFX = require(Client:WaitForChild("BladeFX"))
local CombatCamera = require(Client:WaitForChild("CombatCamera"))
local DashFX = require(Client:WaitForChild("DashFX"))
local ImpactVFX = require(Client:WaitForChild("ImpactVFX"))
local SheathVisuals = require(Client:WaitForChild("SheathVisuals"))
local ClientState = require(Client:WaitForChild("ClientState"))
local SoundFX = require(Client:WaitForChild("SoundFX"))

local IaiController = {}

local player = Players.LocalPlayer
local WEAPON = "Katana"
local ACTION = "KatanaIai"

-- the charge sfx is a riser that ends in a hard cut, starting it halfway in
-- makes the peak line up with full charge (~1s)
local CHARGE_SOUND_START = 2.7

local function now()
	return workspace:GetServerTimeNow()
end

local function getChar()
	local char = player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	local root = char and char:FindFirstChild("HumanoidRootPart")
	if hum and root and hum.Health > 0 then
		return char, hum, root
	end
	return nil, nil, nil
end

-- same collision swap the server does, just so we don't wait on the network
local function setGroup(char, group)
	for _, d in char:GetDescendants() do
		if d:IsA("BasePart") then
			d.CollisionGroup = group
		end
	end
end

local function dash(root, dir, dist, duration)
	local char = root.Parent
	setGroup(char, "Dashing")
	task.delay(duration + 0.25, setGroup, char, "Combatants") -- matches the server, +0.25 or you clip on the way out
	DashMotion.run(root, dir, dist / duration, duration, 0) -- 0 = no sliding after
end

function IaiController.start(config, bar, slot)
	local cfg = config.Iai
	local chargeBar = slot:FindFirstChild("Charge")
	local fill = chargeBar and chargeBar:FindFirstChild("Fill")

	local startedAt = nil
	local chargeTrack, aura, chargeSound

	local function showCharge(frac)
		if chargeBar and fill then
			chargeBar.BackgroundTransparency = frac and 0.3 or 1
			fill.Size = UDim2.fromScale(frac or 0, 1)
		end
	end

	local function cleanup()
		startedAt = nil
		showCharge(nil)
		bar:setActive("Iai", false)
		AimFacing.hold("iai", false)
		if chargeTrack then
			chargeTrack:Stop(0.05)
			chargeTrack = nil
		end
		if aura then
			aura:Destroy()
			aura = nil
		end
		SoundFX.stop(chargeSound, 0.05)
		chargeSound = nil
	end

	local function release()
		if not startedAt then
			return
		end
		local held = os.clock() - startedAt
		cleanup()
		CombatRequest:FireServer("IaiRelease")

		local char, hum, root = getChar()
		if not char then
			return
		end
		SheathVisuals.setSheathed(char, false)
		if (char:GetAttribute("StunnedUntil") or 0) > now() or not char:FindFirstChild(WEAPON) then
			return
		end

		bar:cooldown("Iai", cfg.Cooldown)
		AimFacing.pulse(0.7)
		local charge = math.clamp(held / cfg.FullCharge, 0, 1)
		local look = root.CFrame.LookVector
		local dir = Vector3.new(look.X, 0, look.Z).Unit
		local from = root.Position
		local dist = IaiPath.distance(char, from, dir, charge)

		local slash = AnimLibrary.load(hum, "IaiSlash")
		if slash then
			slash:Play(0.03)
		end
		BladeFX.pulse(char, 0.03, 0.3)
		DashFX.play(char)
		CombatCamera.kick(14)
		ImpactVFX.line(from, from + dir * dist)
		SoundFX.play("IaiRelease", root, { volume = 0.6 + 0.4 * charge })
		SoundFX.play("SwingHeavy", root, { pitch = 1.2 })
		dash(root, dir, dist, cfg.DashTime)
	end

	local function begin()
		local char, hum, root = getChar()
		if not char or startedAt then
			return
		end
		local stunned = (char:GetAttribute("StunnedUntil") or 0) > now()
		if stunned or char:GetAttribute("Blocking") or DrawState.isDrawing(char) then
			return
		end
		if not bar:isReady("Iai") or not ClientState.canAttack(char) then
			return
		end

		local started = os.clock()
		startedAt = started
		CombatRequest:FireServer("IaiStart")

		bar:press("Iai")
		bar:setActive("Iai", true)
		AimFacing.hold("iai", true)
		SheathVisuals.setSheathed(char, true)
		chargeTrack = AnimLibrary.load(hum, "IaiCharge")
		if chargeTrack then
			chargeTrack.Looped = true
			chargeTrack:Play(0.12)
		end
		aura = ImpactVFX.attach("IaiAura", root)
		chargeSound = SoundFX.loop("IaiCharge", root, { startAt = CHARGE_SOUND_START })

		task.delay(cfg.MaxHold, function()
			if startedAt == started then
				release()
			end
		end)
	end

	RunService.RenderStepped:Connect(function()
		if startedAt then
			showCharge(math.clamp((os.clock() - startedAt) / cfg.FullCharge, 0, 1))
		end
	end)

	local function onInput(_, state)
		if state == Enum.UserInputState.Begin then
			begin()
		elseif state == Enum.UserInputState.End then
			release()
		end
		return Enum.ContextActionResult.Sink
	end

	local function bind()
		ContextActionService:BindAction(ACTION, onInput, true, cfg.Key, Enum.KeyCode.ButtonX)
		ContextActionService:SetTitle(ACTION, "IAI")
	end

	local function unbind()
		if startedAt then
			cleanup()
			CombatRequest:FireServer("IaiRelease") -- server cancels it since there's no sword in hand
		end
		ContextActionService:UnbindAction(ACTION)
	end

	local function watch(char)
		char.ChildAdded:Connect(function(c)
			if c:IsA("Tool") and c.Name == WEAPON then
				bind()
			end
		end)
		char.ChildRemoved:Connect(function(c)
			if c:IsA("Tool") and c.Name == WEAPON then
				unbind()
			end
		end)
		if char:FindFirstChild(WEAPON) then
			bind()
		end
	end

	player.CharacterAdded:Connect(function(char)
		cleanup()
		ContextActionService:UnbindAction(ACTION)
		watch(char)
	end)
	if player.Character then
		watch(player.Character)
	end
end

return IaiController
