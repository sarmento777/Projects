-- duel vs the sensei, from accepting to the end:
--   Prepare (fade out) -> stage setup -> Intro -> Countdown -> Fight
--   -> someone drops to a knee -> End -> Outro (fade) -> everything goes back -> Finish
--
-- the client only asks to start (after talking to him), everything else is decided
-- here and DuelClient just plays it

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Combat = ReplicatedStorage:WaitForChild("Combat")
local CombatConfig = require(Combat:WaitForChild("CombatConfig"))
local DialogueData = require(Combat:WaitForChild("DialogueData"))
local DuelRemote = Combat:WaitForChild("Remotes"):WaitForChild("Duel")

local ServerCombat = script.Parent.Parent
local DamageService = require(ServerCombat:WaitForChild("DamageService"))
local CombatResolver = require(ServerCombat:WaitForChild("CombatResolver"))
local SheathService = require(ServerCombat:WaitForChild("SheathService"))
local DuelistBrain = require(ServerCombat:WaitForChild("NPC"):WaitForChild("DuelistBrain"))
local DuelStage = require(script.Parent:WaitForChild("DuelStage"))
local DuelBarks = require(script.Parent:WaitForChild("DuelBarks"))

local DuelService = {}

local DUEL = CombatConfig.Duel
local TIMING = {
	Fade = 0.8,
	Intro = 3.6,
	CountStep = 0.8, -- per number, 3 2 1
	Result = 5.5, -- win/lose screen + his last lines
}

local sensei
local current = nil -- only one sensei so only one duel at a time

local function send(duel, action, data)
	if duel.player.Parent then
		DuelRemote:FireClient(duel.player, action, data or {})
	end
end

local function hpRatio(model)
	local hum = model:FindFirstChildOfClass("Humanoid")
	return hum and hum.Health / math.max(hum.MaxHealth, 1) or 0
end

-- player left / reset / sensei got removed etc
local function valid(duel)
	local char = duel.player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	return current == duel
		and duel.player.Parent ~= nil
		and char == duel.character
		and hum ~= nil
		and hum.Health > 0
		and sensei.Parent ~= nil
end

local function cleanup(duel)
	for _, c in duel.connections do
		c:Disconnect()
	end
	table.clear(duel.connections)
	if duel.brain then
		duel.brain:stop()
	end
	DuelStage.restore(duel.player.Parent and duel.player or nil, sensei)
	if current == duel then
		current = nil
	end
end

local function abort(duel)
	if duel.closed then
		return
	end
	duel.closed = true
	duel.over = true
	cleanup(duel)
	send(duel, "Finish", { aborted = true })
end

local function finish(duel, won)
	if duel.over then
		return
	end
	duel.over = true
	duel.brain:stop()
	DuelStage.lock({ duel.character, sensei }, true)

	-- "until one of us drops to a knee". small delay so the last hit reads first
	local loser = won and sensei or duel.character
	task.delay(0.35, function()
		if not duel.closed and loser.Parent then
			loser:SetAttribute("Kneeling", true)
		end
	end)

	local plr = duel.player
	plr:SetAttribute("DuelsFought", (plr:GetAttribute("DuelsFought") or 0) + 1)
	if won then
		plr:SetAttribute("DuelsWon", (plr:GetAttribute("DuelsWon") or 0) + 1)
	end
	send(duel, "End", {
		won = won,
		speaker = DialogueData.Sensei.Name,
		lines = won and DialogueData.Ending.Win or DialogueData.Ending.Lose,
		duration = TIMING.Result,
	})
	task.wait(TIMING.Result)
	if duel.closed then
		return
	end
	send(duel, "Outro", { fade = TIMING.Fade })
	task.wait(TIMING.Fade + 0.1)
	if duel.closed then
		return
	end
	duel.closed = true
	cleanup(duel)
	send(duel, "Finish", { won = won })
end

-- barks + phase 2 while fighting
local function watchFight(duel)
	local char = duel.character
	local barks = duel.barks
	local conns = duel.connections

	table.insert(conns, CombatResolver.Parried:Connect(function(defender, attacker)
		if defender == char and attacker == sensei then
			barks:say("PlayerParry")
		elseif defender == sensei and attacker == char then
			barks:say("SenseiParry", { chance = 0.7 })
		end
	end))

	table.insert(conns, DamageService.Damaged:Connect(function(target, _, _, info)
		if duel.over then
			return
		end
		if target == sensei then
			if info.kind == "Iai" then
				barks:say("PlayerIaiHit", { force = true })
			elseif info.combo == 3 then
				barks:say("PlayerStagger", { chance = 0.5 })
			end
			-- half hp, he stops holding back
			if duel.phase == 1 and hpRatio(sensei) <= DUEL.Phase2At then
				duel.phase = 2
				duel.brain:setPhase(2)
				send(duel, "Phase", { phase = 2 })
				barks:say("Phase2", { force = true })
			end
		elseif target == char then
			if info.tag == "GUARD BREAK" then
				barks:say("GuardBreak")
			end
			if hpRatio(char) < CombatConfig.HUD.LowHealth then
				barks:once("PlayerLow")
			end
		end
	end))

	table.insert(conns, duel.brain.Action:Connect(function(action)
		if action == "Iai" then
			barks:say("SenseiIai", { force = true })
		elseif action == "Dodge" then
			barks:say("Dodge", { chance = 0.5 })
		elseif action == "IaiDodged" then
			barks:say("IaiDodged", { force = true })
		end
	end))

	table.insert(conns, DamageService.Defeated:Connect(function(target)
		if target == sensei then
			finish(duel, true)
		elseif target == char then
			finish(duel, false)
		end
	end))
end

local function watchExit(duel)
	local hum = duel.character:FindFirstChildOfClass("Humanoid")
	table.insert(duel.connections, duel.player.CharacterRemoving:Connect(function()
		abort(duel)
	end))
	if hum then
		table.insert(duel.connections, hum.Died:Connect(function()
			abort(duel)
		end))
	end
end

local function run(plr, difficulty)
	local settings = DUEL.Difficulty[difficulty]
	-- print("duel start", plr.Name, difficulty)
	local duel = {
		player = plr,
		character = plr.Character,
		difficulty = difficulty,
		phase = 1,
		connections = {},
		over = false,
		closed = false,
	}
	current = duel
	duel.character:SetAttribute("CombatLocked", true)
	watchExit(duel)

	send(duel, "Prepare", { fade = TIMING.Fade })
	task.wait(TIMING.Fade + 0.15)
	if not valid(duel) then
		return abort(duel)
	end

	DuelStage.setup(plr, sensei, settings)
	duel.brain = DuelistBrain.new(sensei, duel.character, settings)
	duel.barks = DuelBarks.new(plr)
	-- starting it now so he's already facing you in the intro, CombatLocked keeps him still
	duel.brain:start()

	send(duel, "Intro", { sensei = sensei, difficulty = difficulty, duration = TIMING.Intro })
	task.wait(TIMING.Intro)
	if not valid(duel) then
		return abort(duel)
	end

	send(duel, "Countdown", { step = TIMING.CountStep })
	DuelStage.drawKatanas(plr, sensei)
	task.wait(TIMING.CountStep * 3)
	if not valid(duel) then
		return abort(duel)
	end

	DuelStage.lock({ duel.character, sensei }, false)
	watchFight(duel)
	send(duel, "Fight", { sensei = sensei })
	task.delay(0.7, function()
		if not duel.over then
			duel.barks:say("Start", { force = true })
		end
	end)
end

local lastRequest = setmetatable({}, { __mode = "k" })

local function canStart(plr, difficulty)
	if current or type(difficulty) ~= "string" or not DUEL.Difficulty[difficulty] then
		return false
	end
	if os.clock() - (lastRequest[plr] or 0) < 2 then
		return false
	end
	lastRequest[plr] = os.clock()

	local char = plr.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	local root = char and char:FindFirstChild("HumanoidRootPart")
	local sRoot = sensei:FindFirstChild("HumanoidRootPart")
	if not (hum and hum.Health > 0 and root and sRoot) then
		return false
	end
	-- has to actually be next to him, not firing the remote from across the map
	return (root.Position - sRoot.Position).Magnitude <= DUEL.TalkDistance
end

function DuelService.start()
	sensei = workspace:WaitForChild("Sensei")
	DuelStage.init(sensei)
	local root = sensei:FindFirstChild("HumanoidRootPart")
	if root then
		-- server moves him, so server owns his physics. pcall bc it errors if anchored
		pcall(function()
			root:SetNetworkOwner(nil)
		end)
	end
	task.spawn(SheathService.attach, sensei) -- sheath on his back even outside the duel

	local prompt = root and root:FindFirstChildOfClass("ProximityPrompt")
	if prompt then
		prompt.Triggered:Connect(function(plr)
			if not current then
				DuelStage.faceVisitor(sensei, plr)
			end
		end)
	end

	DuelRemote.OnServerEvent:Connect(function(plr, action, difficulty)
		if action == "Start" and canStart(plr, difficulty) then
			task.spawn(run, plr, difficulty)
		end
	end)

	Players.PlayerRemoving:Connect(function(plr)
		if current and current.player == plr then
			abort(current)
		end
	end)
end

return DuelService
