local CameraShots = {}

local UP = Vector3.yAxis

local function flat(v)
	return Vector3.new(v.X, 0, v.Z)
end

local function facing(model)
	local root = model:FindFirstChild("HumanoidRootPart")
	local look = root and root.CFrame.LookVector or model:GetPivot().LookVector
	return flat(look).Unit
end

function CameraShots.head(model: Model): Vector3
	local head = model:FindFirstChild("Head")
	if head then
		return head.Position
	end
	return model:GetPivot().Position + UP * 1.5
end

-- over the viewer's shoulder: viewer on the right of the frame, subject on the left
-- numbers were tuned by eye in studio, closer than this and the head fills the screen
function CameraShots.overShoulder(viewer: Model, subject: Model, side: number?): CFrame
	local from = CameraShots.head(viewer)
	local to = CameraShots.head(subject)
	local dir = flat(to - from)
	dir = dir.Magnitude > 0.1 and dir.Unit or facing(viewer)
	local right = dir:Cross(UP)
	local pos = from - dir * 3.6 - right * 3 * (side or 1) + UP * 0.5
	return CFrame.lookAt(pos, to:Lerp(from, 0.35) - UP * 0.3)
end

-- face close up. angle in degrees around them, 0 = straight in front
function CameraShots.closeUp(subject: Model, angle: number, distance: number, height: number?): CFrame
	local head = CameraShots.head(subject)
	local dir = CFrame.fromAxisAngle(UP, math.rad(angle)):VectorToWorldSpace(facing(subject))
	local pos = head + dir * distance + UP * (height or 0)
	return CFrame.lookAt(pos, head - UP * 0.15)
end

-- side view with both in frame. slide moves the camera along the line between them
function CameraShots.side(a: Model, b: Model, distance: number, height: number, slide: number?): CFrame
	local pa, pb = a:GetPivot().Position, b:GetPivot().Position
	local mid = pa:Lerp(pb, 0.5)
	local line = flat(pb - pa)
	line = line.Magnitude > 0.1 and line.Unit or Vector3.xAxis
	local normal = line:Cross(UP)
	local pos = mid + normal * distance + UP * height + line * (slide or 0)
	return CFrame.lookAt(pos, mid + UP * 0.8)
end

return CameraShots
