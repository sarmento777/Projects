local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")

local CombatConfig = require(ReplicatedStorage:WaitForChild("Combat"):WaitForChild("CombatConfig"))

local Combat = script.Parent.Parent
local DummyService = require(Combat:WaitForChild("DummyService"))
local IaiService = require(Combat:WaitForChild("IaiService"))
local CombatResolver = require(Combat:WaitForChild("CombatResolver"))
local NpcKatana = require(Combat:WaitForChild("NPC"):WaitForChild("NpcKatana"))

local DuelStage = {}

local DUEL = CombatConfig.Duel
local TAG = "Combatant"
local ROOT_HEIGHT = 3 -- r6 root sits 3 studs off the ground

-- stuff that only exists during a duel, or got left over from a hit mid-swing
local DUEL_ATTRIBUTES = {
	"NonLethal", "CombatLocked", "DamageScale", "StunnedUntil",
	"Blocking", "BlockStart", "IaiCharging", "Kneeling",
}

local senseiHome = nil

local function humOf(model)
	return model and model:FindFirstChildOfClass("Humanoid")
end

local function promptOf(sensei)
	local root = sensei:FindFirstChild("HumanoidRootPart")
	return root and root:FindFirstChildOfClass("ProximityPrompt")
end

local function groundAt(pos)
	local ignore = { workspace:FindFirstChild("Sheaths"), workspace:FindFirstChild("Dummies"), workspace:FindFirstChild("Sensei") }
	for _, plr in Players:GetPlayers() do
		table.insert(ignore, plr.Character)
	end
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = ignore
	local hit = workspace:Raycast(pos + Vector3.new(0, 40, 0), Vector3.new(0, -120, 0), params)
	return hit and hit.Position or pos
end

local function place(model, pos, lookAt)
	local at = groundAt(pos) + Vector3.new(0, ROOT_HEIGHT, 0)
	model:PivotTo(CFrame.lookAt(at, Vector3.new(lookAt.X, at.Y, lookAt.Z)))
	local root = model:FindFirstChild("HumanoidRootPart")
	if root then
		root.AssemblyLinearVelocity = Vector3.zero
		root.AssemblyAngularVelocity = Vector3.zero
	end
end

local function clearAttributes(model)
	for _, name in DUEL_ATTRIBUTES do
		model:SetAttribute(name, nil)
	end
end

local function heal(model)
	local hum = humOf(model)
	if hum and hum.Health > 0 then
		hum.Health = hum.MaxHealth
	end
end

local function calmDown(model)
	IaiService.cancel(model)
	if model:GetAttribute("Blocking") then
		CombatResolver.setBlocking(model, false)
	end
end

function DuelStage.init(sensei: Model)
	senseiHome = sensei:GetPivot()
end

function DuelStage.faceVisitor(sensei: Model, plr: Player)
	local root = sensei:FindFirstChild("HumanoidRootPart")
	local other = plr.Character and plr.Character:FindFirstChild("HumanoidRootPart")
	if not (root and other) then
		return
	end
	local from = root.CFrame
	local at = from.Position
	local goal = CFrame.lookAt(at, Vector3.new(other.Position.X, at.Y, other.Position.Z))
	task.spawn(function()
		for i = 1, 12 do
			local a = i / 12
			root.CFrame = from:Lerp(goal, a * a * (3 - 2 * a))
			task.wait()
		end
	end)
end

function DuelStage.lock(models: { Model }, on: boolean)
	for _, model in models do
		if model.Parent then
			model:SetAttribute("CombatLocked", on or nil)
		end
	end
end

function DuelStage.setup(plr: Player, sensei: Model, settings)
	local char = plr.Character
	local half = Vector3.new(0, 0, DUEL.Spacing / 2)
	local senseiSpot = DUEL.Center - half -- dojo side
	local playerSpot = DUEL.Center + half

	DummyService.stash()

	local sHum = humOf(sensei)
	clearAttributes(sensei)
	sHum.MaxHealth = DUEL.SenseiHealth
	sHum.Health = DUEL.SenseiHealth
	sensei:SetAttribute("NonLethal", true)
	sensei:SetAttribute("CombatLocked", true)
	sensei:SetAttribute("DamageScale", settings.Damage)
	NpcKatana.sheathe(sensei)
	place(sensei, senseiSpot, playerSpot)
	-- the brain moves him from the server, so the server has to own him
	pcall(function()
		sensei.HumanoidRootPart:SetNetworkOwner(nil)
	end)
	CollectionService:AddTag(sensei, TAG)
	local prompt = promptOf(sensei)
	if prompt then
		prompt.Enabled = false
	end

	-- player starts sheathed, draws on the countdown
	calmDown(char)
	clearAttributes(char)
	char:SetAttribute("NonLethal", true)
	char:SetAttribute("CombatLocked", true)
	local hum = humOf(char)
	if hum then
		hum:UnequipTools()
		hum.WalkSpeed = char:GetAttribute("BaseWalkSpeed") or 16
	end
	heal(char)
	place(char, playerSpot, senseiSpot)
end

function DuelStage.drawKatanas(plr: Player, sensei: Model)
	NpcKatana.draw(sensei)
	local char = plr.Character
	local hum = humOf(char)
	local tool = plr:FindFirstChildOfClass("Backpack") and plr.Backpack:FindFirstChild("Katana")
	if hum and tool and not char:FindFirstChild("Katana") then
		hum:EquipTool(tool)
	end
end

function DuelStage.restore(plr: Player?, sensei: Model)
	calmDown(sensei)
	NpcKatana.sheathe(sensei)
	CollectionService:RemoveTag(sensei, TAG)
	clearAttributes(sensei)
	local sHum = humOf(sensei)
	if sHum then
		sHum.WalkSpeed = 16
		sHum.Health = sHum.MaxHealth
	end
	if senseiHome then
		sensei:PivotTo(senseiHome)
		local root = sensei:FindFirstChild("HumanoidRootPart")
		if root then
			root.AssemblyLinearVelocity = Vector3.zero
		end
	end
	local prompt = promptOf(sensei)
	if prompt then
		prompt.Enabled = true
	end

	-- plr is nil when they left mid duel
	local char = plr and plr.Character
	if char then
		calmDown(char)
		clearAttributes(char)
		heal(char)
		local hum = humOf(char)
		if hum then
			hum.WalkSpeed = char:GetAttribute("BaseWalkSpeed") or 16
		end
	end

	DummyService.unstash()
end

return DuelStage
