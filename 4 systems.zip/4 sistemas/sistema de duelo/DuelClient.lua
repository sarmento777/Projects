-- plays the duel the server runs (Remotes.Duel). each server step maps to a function
-- in `steps`: Prepare, Intro, Countdown, Fight, Bark, Phase, End, Outro, Finish

local Players = game:GetService("Players")
local Lighting = game:GetService("Lighting")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Combat = ReplicatedStorage:WaitForChild("Combat")
local DuelRemote = Combat:WaitForChild("Remotes"):WaitForChild("Duel")
local DialogueData = require(Combat:WaitForChild("DialogueData"))

local Client = script.Parent.Parent
local UI = require(Client:WaitForChild("UI"))
local ClientState = require(Client:WaitForChild("ClientState"))
local CameraShake = require(Client:WaitForChild("CameraShake"))
local Soundscape = require(Client:WaitForChild("Soundscape"))
local DuelHUD = require(script.Parent:WaitForChild("DuelHUD"))
local ScreenFade = require(script.Parent:WaitForChild("ScreenFade"))
local CutsceneCamera = require(script.Parent:WaitForChild("CutsceneCamera"))
local CameraShots = require(script.Parent:WaitForChild("CameraShots"))

local DuelClient = {}

local player = Players.LocalPlayer
local LOCK = "duel"

local DIFFICULTY_LABEL = {
	Easy = "Treino leve",
	Normal = "Desafio",
	Hard = "Sem piedade",
}

local hud
local running = false
local sensei = nil
local gradeBefore = nil

local function lerp(a, b, t)
	return a + (b - a) * t
end

local function rootPos(model)
	local root = model and model:FindFirstChild("HumanoidRootPart")
	return root and root.Position
end

-- desaturate a bit at the end of the fight, Finish puts it back
local function grade(on)
	local cc = Lighting:FindFirstChild("Grade")
	if not cc then
		return
	end
	if on then
		gradeBefore = gradeBefore or { Saturation = cc.Saturation, Contrast = cc.Contrast }
		UI.tween(cc, 0.8, { Saturation = gradeBefore.Saturation - 0.35, Contrast = gradeBefore.Contrast + 0.08 })
	elseif gradeBefore then
		UI.tween(cc, 0.6, gradeBefore)
		gradeBefore = nil
	end
end

local steps = {}

function steps.Prepare(data)
	running = true
	ClientState.lock(LOCK)
	ClientState.hideHud(LOCK, true)
	CutsceneCamera.begin() -- freeze the current view while it fades
	Soundscape.music(nil, data.fade or 0.8)
	Soundscape.duck(true)
	ScreenFade.toBlack(data.fade or 0.8)
end

function steps.Intro(data)
	sensei = data.sensei
	local me = player.Character
	if not (sensei and me) then
		return
	end
	local total = data.duration or 3.6
	local first = total * 0.52

	hud:letterbox(true, 0)
	CutsceneCamera.begin()
	-- shot 1: low angle on his face, slowly orbiting
	CutsceneCamera.play(function(a)
		return CameraShots.closeUp(sensei, lerp(-40, -12, a), lerp(6, 4.6, a), lerp(-0.6, -0.3, a)), lerp(50, 44, a)
	end, first)
	task.spawn(ScreenFade.fromBlack, 0.6)
	task.delay(0.45, function()
		hud:titleCard(string.format("%s  ·  %s", DialogueData.Sensei.Name, DIFFICULTY_LABEL[data.difficulty] or ""))
	end)
	task.wait(first)

	-- shot 2: both of them from the side
	CutsceneCamera.play(function(a)
		return CameraShots.side(me, sensei, lerp(14, 12.5, a), 2.6, lerp(-4, 2, a)), 55
	end, total - first)
	task.wait(math.max(total - first - 0.45, 0))
	hud:hideTitleCard()
end

function steps.Countdown(data)
	Soundscape.music("Duel", 1)
	CutsceneCamera.finish(rootPos(sensei))
	hud:letterbox(false, 0.45)
	ClientState.hideHud(LOCK, false)
	if sensei then
		hud:showBoss(sensei)
	end
	hud:countdown(data.step or 0.8)
end

function steps.Fight()
	ClientState.unlock(LOCK)
end

function steps.Bark(data)
	hud:bark(data.speaker or DialogueData.Sensei.Name, data.text or "")
end

function steps.Phase(data)
	hud:phase(data.phase or 2)
	CameraShake.add(0.35)
end

function steps.End(data)
	ClientState.lock(LOCK)
	local me = player.Character
	local won = data.won == true
	local total = data.duration or 5.5

	grade(true)
	Soundscape.music(nil, 0.6) -- cut the music so the result sting hits
	task.delay(0.5, function()
		hud:hideBoss()
		ClientState.hideHud(LOCK, true)
		hud:letterbox(true, 0.6)
		if me and sensei then
			CutsceneCamera.begin()
			CutsceneCamera.play(function(a)
				return CameraShots.side(sensei, me, lerp(13, 10.5, a), lerp(2.2, 3, a), lerp(-3, 3, a)), 50
			end, total)
		end
	end)

	task.wait(0.7)
	hud:result(won, won and "O sensei caiu de joelhos." or "Você caiu de joelhos.")
	task.wait(1.8)
	hud:hideResult()
	for _, line in ipairs(data.lines or {}) do
		hud:bark(data.speaker or DialogueData.Sensei.Name, line)
		task.wait(1.6)
	end
end

function steps.Outro(data)
	ScreenFade.toBlack(data.fade or 0.8)
end

function steps.Finish()
	hud:reset()
	CutsceneCamera.finish()
	grade(false)
	ClientState.unlock(LOCK)
	ClientState.hideHud(LOCK, false)
	Soundscape.duck(false)
	Soundscape.music("Explore", 2.5)
	sensei = nil
	running = false
	ScreenFade.fromBlack(0.7)
end

-- fires the request and waits for Prepare. false if the server said no (cooldown, too far...)
function DuelClient.request(difficulty: string): boolean
	if running then
		return false
	end
	DuelRemote:FireServer("Start", difficulty)
	local deadline = os.clock() + 2.5
	while not running and os.clock() < deadline do
		task.wait()
	end
	return running
end

function DuelClient.isRunning(): boolean
	return running
end

function DuelClient.start()
	hud = DuelHUD.new(player:WaitForChild("PlayerGui"):WaitForChild("DuelGui"))
	hud:reset()
	DuelRemote.OnClientEvent:Connect(function(action, data)
		local step = steps[action]
		if step then
			step(data or {})
		end
	end)
end

return DuelClient
