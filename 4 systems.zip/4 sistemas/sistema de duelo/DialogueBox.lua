-- the dialogue box built in Studio (StarterGui.DialogueGui)
-- typewriter text, click/space finishes the line or goes to the next one
-- choices become buttons (click or 1-4)

local UserInputService = game:GetService("UserInputService")

local UI = require(script.Parent.Parent:WaitForChild("UI"))
local SoundFX = require(script.Parent.Parent:WaitForChild("SoundFX"))

local DialogueBox = {}
DialogueBox.__index = DialogueBox

local CPS = 48
local PAUSE = { ["."] = 0.22, [","] = 0.08, ["?"] = 0.22, ["!"] = 0.22 }
local ADVANCE_KEYS = {
	[Enum.KeyCode.Space] = true,
	[Enum.KeyCode.Return] = true,
	[Enum.KeyCode.ButtonA] = true,
}
local NUMBER_KEYS = { Enum.KeyCode.One, Enum.KeyCode.Two, Enum.KeyCode.Three, Enum.KeyCode.Four }
local GOLD = Color3.fromRGB(232, 196, 112)
local BLIP_EVERY = 3 -- a blip on every letter sounds like a machine gun

function DialogueBox.new(gui: ScreenGui)
	local root = gui:WaitForChild("Root")
	local box = root:WaitForChild("Box")
	local self = setmetatable({
		root = root,
		box = box,
		shade = root:WaitForChild("Shade"),
		body = box:WaitForChild("Body"),
		speaker = box:WaitForChild("NameTag"):WaitForChild("Speaker"),
		title = box:WaitForChild("SpeakerTitle"),
		continueHint = box:WaitForChild("Continue"),
		portrait = box:WaitForChild("PortraitHolder"):WaitForChild("Portrait"),
		choices = root:WaitForChild("Choices"),
		template = root.Choices:WaitForChild("ChoiceTemplate"),
		boxHome = box.Position,
		advanced = Instance.new("BindableEvent"),
		picked = Instance.new("BindableEvent"),
		choosing = false,
		buttons = {},
	}, DialogueBox)

	UserInputService.InputBegan:Connect(function(input, processed)
		if not self.root.Visible then
			return
		end
		if self.choosing then
			local i = table.find(NUMBER_KEYS, input.KeyCode)
			if i and self.buttons[i] then
				self.picked:Fire(i)
			end
			return
		end
		local click = input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch
		if ADVANCE_KEYS[input.KeyCode] or (click and not processed) then
			self.advanced:Fire()
		end
	end)
	return self
end

-- portrait = a clone of the npc in the ViewportFrame with the camera on the face
function DialogueBox:_setPortrait(model)
	for _, c in self.portrait:GetChildren() do
		if not c:IsA("UICorner") then
			c:Destroy()
		end
	end
	if not model then
		return
	end
	-- characters aren't Archivable by default so Clone() returns nil
	local archivable = model.Archivable
	model.Archivable = true
	local copy = model:Clone()
	model.Archivable = archivable
	if not copy then
		return
	end
	for _, d in copy:GetDescendants() do
		if d:IsA("ProximityPrompt") or d:IsA("BaseScript") or d:IsA("Tool") then
			d:Destroy()
		end
	end
	copy.Parent = self.portrait

	local head = copy:FindFirstChild("Head")
	local root = copy:FindFirstChild("HumanoidRootPart")
	if head and root then
		local look = root.CFrame.LookVector
		local cam = Instance.new("Camera")
		cam.FieldOfView = 30
		local eye = head.Position + Vector3.new(0, -0.1, 0)
		cam.CFrame = CFrame.lookAt(eye + look * 4.2 + root.CFrame.RightVector * 0.8 + Vector3.new(0, 0.25, 0), eye)
		cam.Parent = self.portrait
		self.portrait.CurrentCamera = cam
	end
end

function DialogueBox:open(name: string, title: string?, portraitModel: Model?)
	self.speaker.Text = name
	self.title.Text = title or ""
	self.body.Text = ""
	self.continueHint.TextTransparency = 1
	self:_setPortrait(portraitModel)

	self.root.Visible = true
	self.box.Position = self.boxHome + UDim2.fromOffset(0, 40)
	self.shade.BackgroundTransparency = 1
	UI.tween(self.box, 0.35, { Position = self.boxHome }, Enum.EasingStyle.Back)
	UI.tween(self.shade, 0.4, { BackgroundTransparency = 0 })
	SoundFX.play("DialogOpen")
end

-- first click finishes the typing, second one moves on. yields until then
function DialogueBox:say(text: string)
	local body = self.body
	body.Text = text
	body.MaxVisibleGraphemes = 0
	self.continueHint.TextTransparency = 1

	local skipped = false
	local skip = self.advanced.Event:Once(function()
		skipped = true
	end)
	local count = utf8.len(text) or #text
	local shown = 0
	for _, code in utf8.codes(text) do
		if skipped then
			break
		end
		shown += 1
		body.MaxVisibleGraphemes = shown
		local ch = utf8.char(code)
		if shown % BLIP_EVERY == 1 and ch ~= " " then
			SoundFX.play("TextBlip")
		end
		task.wait(1 / CPS + (PAUSE[ch] or 0))
	end
	skip:Disconnect()
	body.MaxVisibleGraphemes = -1

	local waiting = true
	task.spawn(function()
		local on = true
		while waiting do
			self.continueHint.TextTransparency = on and 0 or 0.6
			on = not on
			task.wait(0.45)
		end
		self.continueHint.TextTransparency = 1
	end)
	task.wait(0.12) -- otherwise one click can skip two lines
	self.advanced.Event:Wait()
	waiting = false
	SoundFX.play("Hover", nil, { volume = 1.6, pitch = 0.8 })
	return count
end

function DialogueBox:_clearChoices()
	for _, b in self.buttons do
		b:Destroy()
	end
	table.clear(self.buttons)
end

function DialogueBox:_hover(button, on)
	local accent = button:FindFirstChild("Accent")
	local scale = button:FindFirstChildOfClass("UIScale")
	local stroke = button:FindFirstChildOfClass("UIStroke")
	UI.tween(accent, 0.12, { BackgroundTransparency = on and 0 or 1 })
	UI.tween(scale, 0.12, { Scale = on and 1.03 or 1 })
	UI.tween(stroke, 0.12, { Transparency = on and 0.45 or 0.86, Color = on and GOLD or Color3.new(1, 1, 1) })
end

function DialogueBox:choose(options: { string }): number
	self:_clearChoices()
	for i, text in options do
		local b = self.template:Clone()
		b.Name = "Choice" .. i
		b.LayoutOrder = i
		b.Visible = true
		b.Index.Text = tostring(i)
		b.Label.Text = text
		local scale = b:FindFirstChildOfClass("UIScale")
		scale.Scale = 0.85
		b.Parent = self.choices
		-- small stagger so they pop in one after the other
		UI.tween(scale, 0.25, { Scale = 1 }, Enum.EasingStyle.Back, Enum.EasingDirection.Out, (i - 1) * 0.05)

		b.MouseEnter:Connect(function()
			self:_hover(b, true)
			SoundFX.play("Hover")
		end)
		b.MouseLeave:Connect(function()
			self:_hover(b, false)
		end)
		b.Activated:Connect(function()
			self.picked:Fire(i)
		end)
		table.insert(self.buttons, b)
	end

	self.choosing = true
	local index = self.picked.Event:Wait()
	self.choosing = false
	SoundFX.play("Select")

	for i, b in self.buttons do
		if i == index then
			self:_hover(b, true)
		else
			UI.tween(b, 0.15, { BackgroundTransparency = 1 })
		end
	end
	task.wait(0.18)
	self:_clearChoices()
	return index
end

function DialogueBox:close()
	self.choosing = false
	self:_clearChoices()
	UI.tween(self.box, 0.25, { Position = self.boxHome + UDim2.fromOffset(0, 40) }, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	UI.tween(self.shade, 0.25, { BackgroundTransparency = 1 })
	task.wait(0.25)
	self.root.Visible = false
	self.box.Position = self.boxHome
	self:_setPortrait(nil)
end

return DialogueBox
