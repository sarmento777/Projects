-- sensei one-liners during the fight (lines are in DialogueData.Barks)

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Combat = ReplicatedStorage:WaitForChild("Combat")
local CombatConfig = require(Combat:WaitForChild("CombatConfig"))
local DialogueData = require(Combat:WaitForChild("DialogueData"))
local DuelRemote = Combat:WaitForChild("Remotes"):WaitForChild("Duel")

local DuelBarks = {}
DuelBarks.__index = DuelBarks

local LINES = DialogueData.Barks
local SPEAKER = DialogueData.Sensei.Name

type Opts = { force: boolean?, chance: number? }

function DuelBarks.new(plr: Player)
	return setmetatable({
		player = plr,
		rng = Random.new(),
		lastAt = -math.huge,
		lastLine = {},
		used = {},
	}, DuelBarks)
end

function DuelBarks:_pick(key)
	local lines = LINES[key]
	if not lines or #lines == 0 then
		return nil
	end
	local i = self.rng:NextInteger(1, #lines)
	-- don't repeat the last one
	if #lines > 1 and i == self.lastLine[key] then
		i = i % #lines + 1
	end
	self.lastLine[key] = i
	return lines[i]
end

function DuelBarks:say(key: string, opts: Opts?): boolean
	opts = opts or {}
	if opts.chance and self.rng:NextNumber() > opts.chance then
		return false
	end
	if not opts.force and os.clock() - self.lastAt < CombatConfig.Duel.BarkCooldown then
		return false
	end
	local line = self:_pick(key)
	if not line or not self.player.Parent then
		return false
	end
	self.lastAt = os.clock()
	DuelRemote:FireClient(self.player, "Bark", { speaker = SPEAKER, text = line })
	return true
end

function DuelBarks:once(key: string, opts: Opts?): boolean
	if self.used[key] then
		return false
	end
	if self:say(key, opts) then
		self.used[key] = true
		return true
	end
	return false
end

return DuelBarks
