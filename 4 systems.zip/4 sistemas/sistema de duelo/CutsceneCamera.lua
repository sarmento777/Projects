-- cutscene camera. takes control away from CombatCamera, plays shots, gives it back
-- a "shot" is just fn(alpha) -> (CFrame, fov?) where alpha is 0..1 already eased

local RunService = game:GetService("RunService")

local CombatCamera = require(script.Parent.Parent:WaitForChild("CombatCamera"))

local CutsceneCamera = {}

local BIND = "DuelCutscene"
local active = false
local shot = nil -- fn(now) -> (CFrame, fov?)

local function smooth(a)
	return a * a * (3 - 2 * a)
end

local function render()
	if not shot then return end
	local cam = workspace.CurrentCamera
	local cf, fov = shot(os.clock())
	-- set every frame, the default camera scripts like to flip it back
	cam.CameraType = Enum.CameraType.Scriptable
	cam.CFrame = cf
	if fov then
		cam.FieldOfView = fov
	end
end

function CutsceneCamera.isActive(): boolean
	return active
end

function CutsceneCamera.begin()
	if active then
		return
	end
	active = true
	CombatCamera.suspend(true)
	-- hold whatever we're looking at right now until a shot gets played
	local cam = workspace.CurrentCamera
	local cf, fov = cam.CFrame, cam.FieldOfView
	shot = function()
		return cf, fov
	end
	-- +2 so it runs after CombatCamera
	RunService:BindToRenderStep(BIND, Enum.RenderPriority.Camera.Value + 2, render)
end

function CutsceneCamera.cut(cf: CFrame, fov: number?)
	shot = function()
		return cf, fov
	end
end

function CutsceneCamera.play(fn: (number) -> (CFrame, number?), seconds: number)
	local t0 = os.clock()
	shot = function(now)
		return fn(smooth(math.clamp((now - t0) / seconds, 0, 1)))
	end
end

-- from wherever the camera is now to `to`
function CutsceneCamera.glide(to: CFrame, seconds: number, fov: number?)
	local cam = workspace.CurrentCamera
	local from, fromFov = cam.CFrame, cam.FieldOfView
	local toFov = fov or fromFov
	CutsceneCamera.play(function(a)
		return from:Lerp(to, a), fromFov + (toFov - fromFov) * a
	end, seconds)
end

-- lookAt: where the gameplay camera should be pointing when control comes back
function CutsceneCamera.finish(lookAt: Vector3?)
	if not active then
		return
	end
	active = false
	shot = nil
	RunService:UnbindFromRenderStep(BIND)
	if lookAt then
		CombatCamera.lookToward(lookAt)
	end
	CombatCamera.suspend(false)
end

return CutsceneCamera
