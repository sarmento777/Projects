-- tiny signal for server modules. not using BindableEvent bc it copies tables
-- and we pass models/tables around a lot

local Signal = {}
Signal.__index = Signal

function Signal.new()
	return setmetatable({ handlers = {} }, Signal)
end

function Signal:Connect(fn: (...any) -> ())
	local handler = { fn = fn, on = true }
	table.insert(self.handlers, handler)
	return {
		Disconnect = function()
			handler.on = false
			local i = table.find(self.handlers, handler)
			if i then
				table.remove(self.handlers, i)
			end
		end,
	}
end

function Signal:Fire(...)
	-- clone so a handler disconnecting itself mid fire doesn't skip the next one
	for _, handler in table.clone(self.handlers) do
		if handler.on then
			task.spawn(handler.fn, ...)
		end
	end
end

return Signal
