-- the sensei's reflexes. when the target starts a swing we roll parry / block / dodge / nothing,
-- using the difficulty chances + a reaction time
--   parry is a "read", if it comes out it comes out on time
--   block depends on reaction, too slow and the first hit gets through
--   dodge only works if there's time for it (good vs heavy and iai)

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local CombatConfig = require(ReplicatedStorage:WaitForChild("Combat"):WaitForChild("CombatConfig"))

local Combat = script.Parent.Parent
local ComboService = require(Combat:WaitForChild("ComboService"))
local DefenseService = require(Combat:WaitForChild("DefenseService"))
local IaiService = require(Combat:WaitForChild("IaiService"))

local M1 = CombatConfig.M1
local HEAVY = CombatConfig.Heavy
local IAI = CombatConfig.Iai

local GUARD_HOLD = 0.45 -- keep guard up this long after the expected hit
local LATE_BLOCK_SLACK = 0.15
local THREAT_MARGIN = 2.5 -- extra range before we decide a swing is aimed at us

local DuelistDefense = {}
DuelistDefense.__index = DuelistDefense

local function flat(v)
	return Vector3.new(v.X, 0, v.Z)
end

-- getSettings is a function bc the brain swaps cfg tables on phase 2
function DuelistDefense.new(model: Model, target: Model, body, getSettings: () -> any, onAction: (string) -> ())
	local self = setmetatable({}, DuelistDefense)
	self.model = model
	self.target = target
	self.body = body
	self.settings = getSettings
	self.onAction = onAction
	self.rng = Random.new()
	self.guardUntil = 0

	self.connections = {
		ComboService.AttackStarted:Connect(function(attacker, kind, hitDelay, index)
			if attacker == self.target then
				self:_onSwing(kind, hitDelay, index)
			end
		end),
		IaiService.Released:Connect(function(attacker, from, to, cutDelay)
			if attacker == self.target then
				self:_onIai(from, to, cutDelay)
			end
		end),
	}
	return self
end

function DuelistDefense:_canReact()
	local model = self.model
	local hum = model:FindFirstChildOfClass("Humanoid")
	return hum ~= nil
		and hum.Health > 0
		and model:FindFirstChild("Katana") ~= nil
		and not model:GetAttribute("CombatLocked")
		and not model:GetAttribute("IaiCharging")
		and (model:GetAttribute("StunnedUntil") or 0) <= workspace:GetServerTimeNow()
end

function DuelistDefense:_reaction()
	local r = self.settings().Reaction
	return self.rng:NextNumber(r[1], r[2])
end

function DuelistDefense:isGuarding(): boolean
	return self.model:GetAttribute("Blocking") == true
end

function DuelistDefense:guard(seconds: number, allowParry: boolean?): boolean
	if self:isGuarding() then
		self.guardUntil = math.max(self.guardUntil, os.clock() + seconds)
		return true
	end
	if DefenseService.setGuard(self.model, true, allowParry == true) then
		self.guardUntil = os.clock() + seconds
		return true
	end
	return false
end

function DuelistDefense:lower()
	self.guardUntil = 0
	if self:isGuarding() then
		DefenseService.setGuard(self.model, false)
	end
end

-- brain calls this every tick
function DuelistDefense:update()
	if self:isGuarding() and os.clock() >= self.guardUntil then
		self:lower()
	end
end

-- raise guard so the hit lands inside the parry window
function DuelistDefense:_timedParry(hitDelay)
	local lead = self.rng:NextNumber(0.05, math.min(0.12, CombatConfig.Block.ParryWindow - 0.05))
	task.delay(math.max(hitDelay - lead, 0), function()
		if self.model:GetAttribute("Blocking") then
			-- parry only counts at the start of a guard, so drop it and raise it again
			DefenseService.setGuard(self.model, false)
		end
		if self:_canReact() then
			self:guard(lead + GUARD_HOLD, true)
		end
	end)
end

function DuelistDefense:_blockAfter(reaction, hitDelay)
	local delay = reaction
	if reaction <= hitDelay + LATE_BLOCK_SLACK then
		delay = math.min(reaction, math.max(hitDelay - 0.03, 0))
	end
	task.delay(delay, function()
		if self:_canReact() then
			self:guard(math.max(hitDelay - delay, 0) + GUARD_HOLD)
		end
	end)
end

function DuelistDefense:_dash(dir, delay, label)
	task.delay(delay, function()
		if self:_canReact() and not self:isGuarding() and DefenseService.dashModel(self.model, dir) then
			self.body:holdFacing(CombatConfig.Dash.Duration)
			self.onAction(label)
		end
	end)
end

-- back and a bit to the side, gets out of the swing arc
function DuelistDefense:_awayDirection()
	local tRoot = self.target:FindFirstChild("HumanoidRootPart")
	local away = tRoot and flat(self.body:position() - tRoot.Position) or Vector3.zero
	if away.Magnitude < 0.1 then
		away = -self.body.root.CFrame.LookVector
	end
	away = flat(away).Unit
	local side = Vector3.new(-away.Z, 0, away.X) * (self.rng:NextNumber() < 0.5 and -1 or 1)
	return (away + side * 0.6).Unit
end

function DuelistDefense:_onSwing(kind, hitDelay, index)
	if not self:_canReact() then
		return -- stunned, their combo is going through
	end
	local range = (kind == "Heavy" and HEAVY.Range or M1.Range) + THREAT_MARGIN
	if self.body:distanceTo(self.target) > range then
		return
	end
	local cfg = self.settings()
	local roll = self.rng:NextNumber()

	if self:isGuarding() then
		if kind == "Heavy" then
			-- heavy breaks guard, so either parry it or get out
			if roll < cfg.Parry then
				self:_timedParry(hitDelay)
			elseif roll < cfg.Parry + cfg.Dodge + cfg.Block * 0.5 then
				self:lower()
				self:_dash(self:_awayDirection(), self:_reaction(), "Dodge")
			end
			return
		end
		self.guardUntil = math.max(self.guardUntil, os.clock() + hitDelay + GUARD_HOLD)
		-- he knows the 3rd hit is the big one
		if index == 3 and roll < cfg.Parry then
			self:_timedParry(hitDelay)
		end
		return
	end

	local parry, block, dodge = cfg.Parry, cfg.Block, cfg.Dodge
	if kind == "M1" and index == 1 then
		parry *= 0.5 -- first hit is the hardest to read
	end
	if kind == "Heavy" then
		-- blocking a heavy = asking for a guard break
		dodge += block * 0.6
		block *= 0.4
	end

	if roll < parry then
		self:_timedParry(hitDelay)
	elseif roll < parry + block then
		self:_blockAfter(self:_reaction(), hitDelay)
	elseif roll < parry + block + dodge then
		self:_dash(self:_awayDirection(), self:_reaction(), "Dodge")
	end
end

-- target released iai, the cut lands in cutDelay
function DuelistDefense:_onIai(from, to, cutDelay)
	if not self:_canReact() then
		return
	end
	local seg = flat(to - from)
	if seg.Magnitude < 0.1 then
		return
	end
	local dir = seg.Unit
	local rel = flat(self.body:position() - from)
	local along = math.clamp(rel:Dot(dir), 0, seg.Magnitude)
	local offLine = (rel - dir * along).Magnitude
	if offLine > IAI.Width + 4 then
		return -- wasn't even in the way
	end

	local cfg = self.settings()
	local roll = self.rng:NextNumber()
	if roll < cfg.Parry * 1.2 then
		-- turn to where it came from and parry on the cut
		self.body:faceFor(from, cutDelay + 0.3)
		self:lower()
		self:_timedParry(cutDelay)
	elseif roll < cfg.Parry * 1.2 + cfg.Dodge + cfg.Block * 0.5 then
		local side = Vector3.new(-dir.Z, 0, dir.X)
		local sideSign = rel:Dot(side)
		if math.abs(sideSign) < 0.1 then
			sideSign = self.rng:NextNumber() - 0.5
		end
		self:lower()
		self:_dash(side * math.sign(sideSign), math.min(self:_reaction(), cutDelay - 0.2), "IaiDodged")
	end
end

function DuelistDefense:destroy()
	for _, c in self.connections do
		c.Disconnect()
	end
	table.clear(self.connections)
	self:lower()
end

return DuelistDefense
