-- the npc's body: walking, turning, distances. the brain decides, this just does it

local RunService = game:GetService("RunService")

local NpcBody = {}
NpcBody.__index = NpcBody

local TURN_RESPONSIVENESS = 18

local function flat(v)
	return Vector3.new(v.X, 0, v.Z)
end

local function rootOf(model)
	return model and model:FindFirstChild("HumanoidRootPart")
end

function NpcBody.new(model: Model)
	local self = setmetatable({}, NpcBody)
	self.model = model
	self.humanoid = model:FindFirstChildOfClass("Humanoid")
	self.root = rootOf(model)
	self.look = nil
	self.override = nil -- { position, untilT }
	self.frozenUntil = 0

	-- AutoRotate fights MoveTo when strafing, so facing is done with an AlignOrientation instead
	self.humanoid.AutoRotate = false
	local att = Instance.new("Attachment")
	att.Name = "FacingAttachment"
	att.Parent = self.root
	local align = Instance.new("AlignOrientation")
	align.Name = "Facing"
	align.Mode = Enum.OrientationAlignmentMode.OneAttachment
	align.Attachment0 = att
	align.Responsiveness = TURN_RESPONSIVENESS
	align.MaxTorque = math.huge
	align.CFrame = self.root.CFrame.Rotation
	align.Parent = self.root
	self.attachment = att
	self.align = align

	self.connection = RunService.Heartbeat:Connect(function()
		self:_turn()
	end)
	return self
end

function NpcBody:_lookPosition()
	local o = self.override
	if o then
		if os.clock() < o.untilT then
			return o.position
		end
		self.override = nil
	end
	if typeof(self.look) == "Vector3" then
		return self.look
	end
	local r = rootOf(self.look)
	return r and r.Position
end

function NpcBody:_turn()
	if os.clock() < self.frozenUntil then
		return
	end
	local pos = self:_lookPosition()
	if not pos then
		return
	end
	local dir = flat(pos - self.root.Position)
	if dir.Magnitude > 0.05 then
		self.align.CFrame = CFrame.lookAt(Vector3.zero, dir)
	end
end

-- model, position or nil
function NpcBody:lookAt(what: (Model | Vector3)?)
	self.look = what
end

-- look at a fixed point for a while (used when parrying an iai)
function NpcBody:faceFor(position: Vector3, seconds: number)
	self.override = { position = position, untilT = os.clock() + seconds }
end

-- lock current facing, for dashes
function NpcBody:holdFacing(seconds: number)
	self.frozenUntil = os.clock() + seconds
end

-- instant turn. the align is too slow for aiming the iai
function NpcBody:snapFace(position: Vector3)
	local pos = self.root.Position
	local dir = flat(position - pos)
	if dir.Magnitude < 0.05 then
		return
	end
	local rot = CFrame.lookAt(Vector3.zero, dir)
	self.root.CFrame = rot + pos
	self.align.CFrame = rot
end

function NpcBody:moveTo(position: Vector3, speed: number)
	-- IaiService sets the slow charge speed, don't stomp it
	if not self.model:GetAttribute("IaiCharging") then
		self.humanoid.WalkSpeed = speed
	end
	self.humanoid:MoveTo(position)
end

function NpcBody:stop()
	self.humanoid:MoveTo(self.root.Position)
end

function NpcBody:position(): Vector3
	return self.root.Position
end

function NpcBody:distanceTo(model: Model): number
	local r = rootOf(model)
	if not r then
		return math.huge
	end
	return flat(r.Position - self.root.Position).Magnitude
end

function NpcBody:destroy()
	self.connection:Disconnect()
	self.align:Destroy()
	self.attachment:Destroy()
	if self.humanoid.Parent then
		self.humanoid.AutoRotate = true
		self:stop()
	end
end

return NpcBody
