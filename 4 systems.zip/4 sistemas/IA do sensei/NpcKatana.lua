-- draw/sheathe for npcs. the tool is a clone of the StarterPack katana, "sheathed" just
-- means it's parented to nil (then the handle shows up on the sheath)
-- drawing plays the same anim as the player since SheathService picks up the equip

local StarterPack = game:GetService("StarterPack")

local NpcKatana = {}

local WEAPON = "Katana"
-- not weak on purpose, a weak table here lost the tool while it was parented to nil
local stored = {}

local function toolFor(model)
	local tool = model:FindFirstChild(WEAPON) or stored[model]
	if not tool then
		local template = StarterPack:FindFirstChild(WEAPON)
		tool = template and template:Clone()
		model.AncestryChanged:Connect(function(_, parent)
			if not parent then
				stored[model] = nil
			end
		end)
	end
	stored[model] = tool
	return tool
end

function NpcKatana.isDrawn(model: Model): boolean
	return model:FindFirstChild(WEAPON) ~= nil
end

function NpcKatana.draw(model: Model)
	local hum = model:FindFirstChildOfClass("Humanoid")
	local tool = toolFor(model)
	if hum and tool and tool.Parent ~= model then
		hum:EquipTool(tool)
	end
end

function NpcKatana.sheathe(model: Model)
	local tool = model:FindFirstChild(WEAPON)
	if tool then
		stored[model] = tool
		tool.Parent = nil
	end
end

return NpcKatana
