-- sensei ai. plays by the exact same rules as the player (ComboService, DefenseService,
-- IaiService), it only decides when to "press the buttons"
--
-- neutral = circle the target and keep spacing, sometimes put guard up. when it's time
-- to attack it picks combo / heavy (if you're turtling) / iai (if you're far). then backs off
-- reactions to your attacks live in DuelistDefense

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local CombatConfig = require(ReplicatedStorage:WaitForChild("Combat"):WaitForChild("CombatConfig"))

local Combat = script.Parent.Parent
local ComboService = require(Combat:WaitForChild("ComboService"))
local DefenseService = require(Combat:WaitForChild("DefenseService"))
local IaiService = require(Combat:WaitForChild("IaiService"))
local CombatResolver = require(Combat:WaitForChild("CombatResolver"))
local Signal = require(Combat:WaitForChild("Signal"))

local NpcBody = require(script.Parent:WaitForChild("NpcBody"))
local DuelistDefense = require(script.Parent:WaitForChild("DuelistDefense"))

local M1 = CombatConfig.M1
local HEAVY = CombatConfig.Heavy
local IAI = CombatConfig.Iai
local DUEL = CombatConfig.Duel

local TICK = 0.1
local RUN = 16
local CIRCLE = 8
local PRESS = 11 -- walking into you mid combo
local COMBO_RANGE = 5
local PERSONAL_SPACE = 3 -- stops a step in front of you instead of glueing to you
local IAI_RANGE = { 11, 20 }
local SPACING = { 7.5, 6.2 } -- neutral distance, phase 1 / phase 2
local IAI_GRACE = 6 -- opening with an iai the second the fight starts felt cheap

local DuelistBrain = {}
DuelistBrain.__index = DuelistBrain

local function flat(v)
	return Vector3.new(v.X, 0, v.Z)
end

local function alive(model)
	local hum = model and model:FindFirstChildOfClass("Humanoid")
	return hum ~= nil and hum.Health > 0
end

local function stunned(model)
	return (model:GetAttribute("StunnedUntil") or 0) > workspace:GetServerTimeNow()
end

-- Phase2 in the config is a list of bonuses on top of the difficulty row
local function withPhase(base, bonus)
	local cfg = table.clone(base)
	for k, add in bonus do
		cfg[k] = (cfg[k] or 0) + add
	end
	return cfg
end

local function comboLength(rng)
	local roll = rng:NextNumber()
	if roll < 0.3 then
		return 2
	elseif roll < 0.72 then
		return 3
	end
	return 4
end

-- settings = one row of CombatConfig.Duel.Difficulty
function DuelistBrain.new(model: Model, target: Model, settings)
	local self = setmetatable({}, DuelistBrain)
	self.model = model
	self.target = target
	self.base = settings
	self.cfg = settings
	self.phase = 1
	self.rng = Random.new()
	self.running = false
	-- "Iai", "Dodge", "IaiDodged", "Punish" -> DuelService uses these for the barks
	self.Action = Signal.new()

	self.nextAttackAt = 0
	self.strafeDir = 1
	self.lastDir = 1 -- strafeDir can be 0 (standing), this remembers the last real side
	self.strafeSwitchAt = 0
	self.punishAt = 0
	self.connections = {}
	return self
end

function DuelistBrain:setPhase(phase: number)
	self.phase = phase
	self.cfg = phase >= 2 and withPhase(self.base, DUEL.Phase2) or self.base
end

function DuelistBrain:start()
	if self.running then
		return
	end
	self.running = true
	self.body = NpcBody.new(self.model)
	self.body:lookAt(self.target)
	self.defense = DuelistDefense.new(self.model, self.target, self.body, function()
		return self.cfg
	end, function(name)
		self.Action:Fire(name)
	end)

	-- we parried them -> they're stunned for a bit, go punish
	table.insert(self.connections, CombatResolver.Parried:Connect(function(defender, attacker)
		if defender == self.model and attacker == self.target then
			self.punishAt = os.clock()
		end
	end))

	self.startedAt = os.clock()
	self.nextAttackAt = os.clock() + self.rng:NextNumber(1.2, 2)
	task.spawn(function()
		while self.running do
			self:_tick()
			task.wait(TICK)
		end
	end)
end

function DuelistBrain:stop()
	if not self.running then
		return
	end
	self.running = false
	for _, c in ipairs(self.connections) do
		c.Disconnect()
	end
	table.clear(self.connections)
	IaiService.cancel(self.model)
	self.defense:destroy()
	self.body:destroy()
end

function DuelistBrain:_free()
	local model = self.model
	return self.running
		and alive(model)
		and alive(self.target)
		and not stunned(model)
		and not model:GetAttribute("CombatLocked")
end

function DuelistBrain:_targetPos()
	local r = self.target:FindFirstChild("HumanoidRootPart")
	return r and r.Position or self.body:position()
end

function DuelistBrain:_awayFromTarget()
	local away = flat(self.body:position() - self:_targetPos())
	if away.Magnitude < 0.1 then
		return -flat(self.body.root.CFrame.LookVector).Unit
	end
	return away.Unit
end

-- right in front of the target, on the side we're already on
function DuelistBrain:_frontOfTarget()
	return self:_targetPos() + self:_awayFromTarget() * PERSONAL_SPACE
end

function DuelistBrain:_inArena(point)
	local offset = flat(point - DUEL.Center)
	if offset.Magnitude <= DUEL.Radius then
		return point, true
	end
	local clamped = DUEL.Center + offset.Unit * DUEL.Radius
	return Vector3.new(clamped.X, point.Y, clamped.Z), false
end

function DuelistBrain:_wait(seconds)
	local deadline = os.clock() + seconds
	while self.running and os.clock() < deadline do
		task.wait(math.min(TICK, deadline - os.clock()))
	end
end

function DuelistBrain:_approach(range, timeout)
	local deadline = os.clock() + timeout
	while os.clock() < deadline do
		if not self:_free() or self.defense:isGuarding() then
			return false
		end
		if self.body:distanceTo(self.target) <= range then
			self.body:stop()
			return true
		end
		self.body:moveTo(self:_frontOfTarget(), RUN)
		task.wait(TICK)
	end
	return false
end

function DuelistBrain:_combo(hits)
	if not self:_approach(COMBO_RANGE, 1.6) then
		return
	end
	for _ = 1, hits do
		if not self:_free() or not ComboService.canAttack(self.model) then
			return -- got parried / stunned mid string
		end
		if self.body:distanceTo(self.target) > M1.Range + 1 then
			break -- they dashed out
		end
		self.body:moveTo(self:_frontOfTarget(), PRESS)
		ComboService.performM1(self.model, nil)
		self:_wait(M1.Cooldown + 0.03)
	end
	-- sometimes tacks a heavy on the end to catch people who just hold block
	if hits == 3 and ComboService.heavyReady(self.model) and self.rng:NextNumber() < 0.3 then
		self:_wait(0.2)
		if self:_free() then
			ComboService.performHeavy(self.model, nil)
			self:_wait(HEAVY.Windup + 0.3)
		end
	end
	self:_recover()
end

function DuelistBrain:_heavy()
	if not self:_approach(HEAVY.Range - 2, 1.4) then
		return
	end
	if ComboService.performHeavy(self.model, nil) then
		self.body:stop()
		self:_wait(HEAVY.Windup + 0.35)
	end
	self:_recover()
end

function DuelistBrain:_iai()
	local model = self.model
	if not IaiService.begin(model, nil) then
		return
	end
	self.Action:Fire("Iai")
	local deadline = os.clock() + self.rng:NextNumber(0.6, 1.0)
	while os.clock() < deadline do
		if not self.running or not alive(model) or stunned(model) then
			IaiService.cancel(model) -- hit while charging, lose it
			return
		end
		self.body:stop()
		task.wait(TICK)
	end
	-- snap aim right before release, then keep facing forward through the dash
	-- otherwise the AlignOrientation drags him around mid dash and it looks wrong
	self.body:snapFace(self:_targetPos())
	self.body:holdFacing(IAI.DashTime + IAI.CutDelay + 0.15)
	IaiService.unleash(model, nil)
	self:_wait(IAI.DashTime + IAI.CutDelay)
end

-- after attacking: step back, or dash back if the roll says so
function DuelistBrain:_recover()
	if not self:_free() then
		return
	end
	local away = self:_awayFromTarget()
	if self.rng:NextNumber() < self.cfg.Dodge and DefenseService.dashModel(self.model, away) then
		self:_wait(CombatConfig.Dash.Duration + 0.1)
		return
	end
	self.body:moveTo(self:_inArena(self.body:position() + away * 5), CIRCLE)
	self:_wait(0.45)
end

function DuelistBrain:_attack(dist)
	local model = self.model
	local roll = self.rng:NextNumber()

	local iaiOk = os.clock() - self.startedAt > IAI_GRACE and IaiService.isReady(model)
	if iaiOk and dist >= IAI_RANGE[1] and dist <= IAI_RANGE[2] and roll < self.cfg.Iai then
		self:_iai()
	elseif self.target:GetAttribute("Blocking") and ComboService.heavyReady(model) then
		self:_heavy() -- guard break
	elseif ComboService.heavyReady(model) and roll > 0.82 then
		self:_heavy()
	else
		self:_combo(comboLength(self.rng))
	end
end

function DuelistBrain:_footwork(dist)
	local t = os.clock()
	if t >= self.strafeSwitchAt then
		-- switch sides, or every now and then just stand and stare
		local roll = self.rng:NextNumber()
		if roll < 0.2 then
			self.strafeDir = 0
		else
			self.strafeDir = roll < 0.6 and -self.lastDir or self.lastDir
			self.lastDir = self.strafeDir
		end
		self.strafeSwitchAt = t + self.rng:NextNumber(1.2, 2.2)
	end

	local desired = SPACING[self.phase] or SPACING[1]
	if self.target:GetAttribute("IaiCharging") then
		desired += 3 -- respect the iai, get off the line
		if self.strafeDir == 0 then
			self.strafeDir = self.lastDir
		end
	end

	local away = self:_awayFromTarget()
	local side = Vector3.new(-away.Z, 0, away.X) * self.strafeDir
	local goal, inside = self:_inArena(self:_targetPos() + away * desired + side * 3)
	if not inside and self.strafeDir ~= 0 then
		-- hit the edge of the sand, go the other way
		self.strafeDir = -self.strafeDir
		self.lastDir = self.strafeDir
	end

	if self.strafeDir == 0 and math.abs(dist - desired) < 1.5 then
		self.body:stop()
	else
		self.body:moveTo(goal, dist > desired + 4 and RUN or CIRCLE)
	end

	-- random guard when you're in his face. *1.5 is just tuning, felt too rare at 1
	if dist < M1.Range + 1.5 and self.rng:NextNumber() < self.cfg.Block * TICK * 1.5 then
		self.defense:guard(self.rng:NextNumber(0.5, 1.0))
	end
end

function DuelistBrain:_tick()
	local model = self.model
	if not alive(model) or not alive(self.target) then
		return
	end
	self.defense:update()

	if model:GetAttribute("CombatLocked") then
		-- intro/countdown. keep pushing the clocks so the fight timer starts on unlock
		self.body:stop()
		self.startedAt = os.clock()
		self.nextAttackAt = os.clock() + 1.5
		return
	end
	if stunned(model) then
		self.defense:lower()
		self.body:stop()
		return
	end
	if self.defense:isGuarding() then
		self.body:stop()
		return
	end

	local dist = self.body:distanceTo(self.target)
	-- print("[brain]", self.phase, math.floor(dist), self.strafeDir)
	local canHit = ComboService.canAttack(model) and not ComboService.isBusy(model)

	if self.punishAt > 0 and os.clock() - self.punishAt < CombatConfig.Block.ParryStun and canHit then
		self.punishAt = 0
		self.Action:Fire("Punish")
		self:_combo(3)
		return
	end

	-- charging iai right next to him? just hit them out of it
	if self.target:GetAttribute("IaiCharging") and dist < M1.Range and canHit then
		self:_combo(2)
		return
	end

	if os.clock() >= self.nextAttackAt and canHit then
		self:_attack(dist)
		-- TODO: aggression could also shorten the recover step, try it after more playtests
		self.nextAttackAt = os.clock() + self.rng:NextNumber(1.0, 2.2) / self.cfg.Aggression
		return
	end

	self:_footwork(dist)
end

return DuelistBrain
