-- single place where damage gets applied. everything that hurts goes through apply()
-- so hit numbers, regen, the duel etc. all stay in sync

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local CombatFX = ReplicatedStorage:WaitForChild("Combat"):WaitForChild("Remotes"):WaitForChild("CombatFX")

local DamageService = {}

local damagedEvent = Instance.new("BindableEvent")
DamageService.Damaged = damagedEvent.Event -- (target, amount, attackerPlayer, info)

-- NonLethal targets (both duelists) stop at 1hp and fire this instead of dying
local defeatedEvent = Instance.new("BindableEvent")
DamageService.Defeated = defeatedEvent.Event -- (target, attackerModel)

function DamageService.getHumanoid(target: Instance?): Humanoid?
	return target and target:FindFirstChildOfClass("Humanoid")
end

function DamageService.isAlive(target: Instance?): boolean
	local hum = DamageService.getHumanoid(target)
	return hum ~= nil and hum.Health > 0
end

-- info: { kind?, heavy?, stagger?, blocked?, combo?, tag?, attacker? }
function DamageService.apply(attacker: Player?, target: Model, amount: number, info)
	info = info or {}
	local hum = DamageService.getHumanoid(target)
	if not hum or hum.Health <= 0 or amount <= 0 then
		return false
	end

	local defeated = false
	if target:GetAttribute("NonLethal") and amount >= hum.Health - 1 then
		amount = math.max(hum.Health - 1, 0)
		defeated = true
	end
	if amount > 0 then
		hum:TakeDamage(amount)
	end
	target:SetAttribute("LastHitBy", attacker and attacker.UserId or 0)
	target:SetAttribute("LastHitTime", workspace:GetServerTimeNow())

	local root = target:FindFirstChild("HumanoidRootPart") or target:FindFirstChild("Head")
	CombatFX:FireAllClients("Damage", {
		target = target,
		amount = amount,
		kind = info.kind,
		position = root and root.Position or target:GetPivot().Position,
		heavy = info.heavy == true or info.stagger == true,
		stagger = info.stagger == true,
		blocked = info.blocked == true,
		tag = info.tag,
		combo = info.combo,
		attackerId = attacker and attacker.UserId or 0,
		attackerModel = info.attacker,
	})

	damagedEvent:Fire(target, amount, attacker, info)
	if defeated then
		defeatedEvent:Fire(target, info.attacker)
	end
	return true
end

return DamageService
