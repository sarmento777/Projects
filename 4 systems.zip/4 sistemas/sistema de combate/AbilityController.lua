local Players = game:GetService("Players")
local ContextActionService = game:GetService("ContextActionService")

local Combat = script.Parent.Parent
local CombatRequest = Combat:WaitForChild("Remotes"):WaitForChild("CombatRequest")
local DrawState = require(Combat:WaitForChild("DrawState"))
local DashMotion = require(Combat:WaitForChild("DashMotion"))
local AnimLibrary = require(script.Parent:WaitForChild("AnimLibrary"))
local DashFX = require(script.Parent:WaitForChild("DashFX"))
local AimFacing = require(script.Parent:WaitForChild("AimFacing"))
local CombatCamera = require(script.Parent:WaitForChild("CombatCamera"))
local ClientState = require(script.Parent:WaitForChild("ClientState"))

local AbilityController = {}

local player = Players.LocalPlayer
local WEAPON = "Katana"

local function now()
	return workspace:GetServerTimeNow()
end

local function getChar()
	local char = player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	if hum and hum.Health > 0 then
		return char, hum
	end
	return nil, nil
end

local function stunned(char)
	return (char:GetAttribute("StunnedUntil") or 0) > now()
end

function AbilityController.start(cfg, bar)
	local blockTrack = nil
	local blocking = false

	local function heavy(_, state)
		if state ~= Enum.UserInputState.Begin then
			return Enum.ContextActionResult.Pass
		end
		local char = getChar()
		if not char or stunned(char) or blocking or DrawState.isDrawing(char) then
			return Enum.ContextActionResult.Sink
		end
		if not bar:isReady("Heavy") or not ClientState.canAttack(char) then
			return Enum.ContextActionResult.Sink
		end
		bar:press("Heavy")
		bar:cooldown("Heavy", cfg.Heavy.Cooldown)
		AimFacing.pulse(cfg.Heavy.Windup + 0.3)
		CombatRequest:FireServer("Heavy")
		return Enum.ContextActionResult.Sink
	end

	local function stopBlock()
		if not blocking then
			return
		end
		blocking = false
		AimFacing.hold("block", false)
		bar:setActive("Block", false)
		bar:cooldown("Block", cfg.Block.Cooldown)
		if blockTrack then
			blockTrack:Stop(0.1)
		end
		CombatRequest:FireServer("BlockEnd")
	end

	local function block(_, state)
		if state == Enum.UserInputState.Begin then
			local char, hum = getChar()
			if not char or stunned(char) or not bar:isReady("Block") or not ClientState.canAttack(char) then
				return Enum.ContextActionResult.Sink
			end
			blocking = true
			AimFacing.hold("block", true)
			bar:press("Block")
			bar:setActive("Block", true)
			-- if we're mid-draw the server raises the guard once the draw is done
			CombatRequest:FireServer("BlockStart")

			blockTrack = AnimLibrary.load(hum, "Block")
			if blockTrack then
				blockTrack.Looped = true
				local track = blockTrack
				task.delay(DrawState.remaining(char), function()
					if blocking and blockTrack == track then
						track:Play(0.08)
					end
				end)
			end
		elseif state == Enum.UserInputState.End or state == Enum.UserInputState.Cancel then
			stopBlock()
		end
		return Enum.ContextActionResult.Sink
	end

	local function dash(_, state)
		if state ~= Enum.UserInputState.Begin then
			return Enum.ContextActionResult.Pass
		end
		local char, hum = getChar()
		if not char or stunned(char) or blocking or not bar:isReady("Dash") or not ClientState.canAttack(char) then
			return Enum.ContextActionResult.Sink
		end
		local root = char:FindFirstChild("HumanoidRootPart")
		local dir = hum.MoveDirection
		if dir.Magnitude < 0.1 then
			dir = root.CFrame.LookVector -- standing still = dash forward
		end
		dir = Vector3.new(dir.X, 0, dir.Z).Unit
		-- print("dash", dir)

		bar:press("Dash")
		bar:cooldown("Dash", cfg.Dash.Cooldown)
		CombatRequest:FireServer("Dash")
		DashFX.play(char)
		CombatCamera.kick(cfg.Camera.DashFov)

		-- applied locally since the client owns its character physics, server only checks the cooldown
		DashMotion.run(root, dir, cfg.Dash.Speed, cfg.Dash.Duration)
		return Enum.ContextActionResult.Sink
	end

	-- CAS so mobile gets buttons for free
	local function bindAll()
		ContextActionService:BindAction("KatanaHeavy", heavy, true, cfg.Heavy.Key, Enum.KeyCode.ButtonY)
		ContextActionService:BindAction("KatanaBlock", block, true, cfg.Block.Key, Enum.KeyCode.ButtonL2)
		ContextActionService:BindAction("KatanaDash", dash, true, cfg.Dash.Key, Enum.KeyCode.ButtonB)
		ContextActionService:SetTitle("KatanaHeavy", "HEAVY")
		ContextActionService:SetTitle("KatanaBlock", "BLOCK")
		ContextActionService:SetTitle("KatanaDash", "DASH")
	end

	local function unbindAll()
		stopBlock()
		ContextActionService:UnbindAction("KatanaHeavy")
		ContextActionService:UnbindAction("KatanaBlock")
		ContextActionService:UnbindAction("KatanaDash")
	end

	local function watchCharacter(char)
		char.ChildAdded:Connect(function(c)
			if c:IsA("Tool") and c.Name == WEAPON then
				bindAll()
			end
		end)
		char.ChildRemoved:Connect(function(c)
			if c:IsA("Tool") and c.Name == WEAPON then
				unbindAll()
			end
		end)
		-- server dropped our guard (stun, guard break) -> sync the local state
		char:GetAttributeChangedSignal("Blocking"):Connect(function()
			if blocking and not char:GetAttribute("Blocking") then
				blocking = false
				AimFacing.hold("block", false)
				bar:setActive("Block", false)
				if blockTrack then
					blockTrack:Stop(0.1)
				end
			end
		end)
		if char:FindFirstChild(WEAPON) then
			bindAll()
		end
	end

	player.CharacterAdded:Connect(function(char)
		unbindAll()
		watchCharacter(char)
	end)
	if player.Character then
		watchCharacter(player.Character)
	end
end

return AbilityController
