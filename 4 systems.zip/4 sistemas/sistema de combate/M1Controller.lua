-- client side of the M1 combo. uses Tool.Activated so it works on pc/mobile/gamepad
-- we predict the swing locally so there's no input delay, but the server still decides hits

local Players = game:GetService("Players")

local Combat = script.Parent.Parent
local CombatRequest = Combat:WaitForChild("Remotes"):WaitForChild("CombatRequest")
local DrawState = require(Combat:WaitForChild("DrawState"))
local SwingPlayer = require(script.Parent:WaitForChild("SwingPlayer"))
local AimFacing = require(script.Parent:WaitForChild("AimFacing"))
local ClientState = require(script.Parent:WaitForChild("ClientState"))

local M1Controller = {}

local player = Players.LocalPlayer
local WEAPON = "Katana"

-- local copy of the server combo rules, only for the visual prediction
-- if you change the combo math in ComboService change it here too!!
local index, lastAttack, busyUntil = 0, 0, 0
local lastPredicted = 0

local function now()
	return workspace:GetServerTimeNow()
end

-- the server echoes our own "Swing" back a moment later, FXHandlers uses this to skip it
function M1Controller.predicted(): boolean
	return os.clock() - lastPredicted < 0.5
end

local function onActivated(cfg)
	local character = player.Character
	local hum = character and character:FindFirstChildOfClass("Humanoid")
	if not hum or hum.Health <= 0 then
		return
	end
	if (character:GetAttribute("StunnedUntil") or 0) > now() or character:GetAttribute("Blocking") then
		return
	end
	if not ClientState.canAttack(character) or DrawState.isDrawing(character) then
		return -- dialogue/cutscene, or still pulling the sword out
	end

	local t = now()
	if t < busyUntil then
		return
	end
	local M1 = cfg.M1
	if t - lastAttack > M1.ComboWindow or index >= #M1.Damage then
		index = 1
	else
		index += 1
	end
	lastAttack = t
	busyUntil = t + (index == #M1.Damage and M1.EndLag or M1.Cooldown)

	lastPredicted = os.clock()
	AimFacing.pulse(0.5)
	SwingPlayer.play(character, index)
	CombatRequest:FireServer("M1")
end

local function hookTool(tool, cfg)
	if tool:IsA("Tool") and tool.Name == WEAPON and not tool:GetAttribute("_m1Hooked") then
		tool:SetAttribute("_m1Hooked", true)
		tool.Activated:Connect(function()
			onActivated(cfg)
		end)
	end
end

function M1Controller.start(cfg)
	local function watch(container)
		for _, c in container:GetChildren() do
			hookTool(c, cfg)
		end
		container.ChildAdded:Connect(function(c)
			hookTool(c, cfg)
		end)
	end

	watch(player:WaitForChild("Backpack"))
	if player.Character then
		watch(player.Character)
	end
	player.CharacterAdded:Connect(function(char)
		watch(char)
		index, lastAttack, busyUntil = 0, 0, 0
	end)
	-- backpack gets recreated on respawn
	player.ChildAdded:Connect(function(c)
		if c:IsA("Backpack") then
			watch(c)
		end
	end)
end

return M1Controller
