local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Combat = ReplicatedStorage:WaitForChild("Combat")
local CombatConfig = require(Combat:WaitForChild("CombatConfig"))
local DrawState = require(Combat:WaitForChild("DrawState"))
local DashMotion = require(Combat:WaitForChild("DashMotion"))
local CombatFX = Combat:WaitForChild("Remotes"):WaitForChild("CombatFX")

local CombatResolver = require(script.Parent:WaitForChild("CombatResolver"))
local ComboService = require(script.Parent:WaitForChild("ComboService"))

local DefenseService = {}

local BLOCK = CombatConfig.Block
local DASH = CombatConfig.Dash

-- keyed by Player for players and by the Model for npcs
local cooldowns = setmetatable({}, { __mode = "k" })

local function now()
	return workspace:GetServerTimeNow()
end

local function cd(key)
	local c = cooldowns[key]
	if not c then
		c = { block = 0, dash = 0 }
		cooldowns[key] = c
	end
	return c
end

local function alive(model)
	local hum = model and model:FindFirstChildOfClass("Humanoid")
	return hum ~= nil and hum.Health > 0
end

local function stunned(model)
	return (model:GetAttribute("StunnedUntil") or 0) > now()
end

local function canBlock(key, char)
	return alive(char)
		and not char:GetAttribute("CombatLocked")
		and char:FindFirstChild("Katana") ~= nil
		-- holding F mid-draw is fine, the guard just comes up once the draw ends
		and not DrawState.isDrawing(char, CombatConfig.Draw.ServerGrace)
		and not char:GetAttribute("Blocking")
		and not char:GetAttribute("IaiCharging")
		and not stunned(char)
		and not ComboService.isBusy(char)
		and now() >= cd(key).block
end

-- if the player can't block right now (stunned, mid swing) we remember they're
-- holding F and raise the guard as soon as it's allowed (see heartbeat below)
function DefenseService.blockStart(plr: Player)
	cd(plr).wantsBlock = true
	if canBlock(plr, plr.Character) then
		CombatResolver.setBlocking(plr.Character, true)
	end
end

function DefenseService.blockEnd(plr: Player)
	local c = cd(plr)
	c.wantsBlock = false
	local char = plr.Character
	if char and char:GetAttribute("Blocking") then
		CombatResolver.setBlocking(char, false)
		c.block = now() + BLOCK.Cooldown
	end
end

function DefenseService.dash(plr: Player)
	local char = plr.Character
	if not alive(char) or stunned(char) or char:GetAttribute("Blocking") or char:GetAttribute("CombatLocked") then
		return
	end
	local c = cd(plr)
	if now() < c.dash then return end
	c.dash = now() + DASH.Cooldown
	-- the client already moved itself (prediction), we just check cooldown and tell everyone else
	CombatFX:FireAllClients("Dash", { character = char })
end

function DefenseService.setGuard(model: Model, on: boolean, allowParry: boolean?): boolean
	if on then
		if not canBlock(model, model) then
			return false
		end
		CombatResolver.setBlocking(model, true, allowParry ~= false)
		return true
	end
	if model:GetAttribute("Blocking") then
		CombatResolver.setBlocking(model, false)
	end
	return true
end

-- npc dash, server moves the body since it owns the physics
function DefenseService.dashModel(model: Model, direction: Vector3): boolean
	local root = model:FindFirstChild("HumanoidRootPart")
	local flat = Vector3.new(direction.X, 0, direction.Z)
	if not root or flat.Magnitude < 0.01 then
		return false
	end
	if not alive(model) or stunned(model) or model:GetAttribute("Blocking") or model:GetAttribute("CombatLocked") then
		return false
	end
	local c = cd(model)
	if now() < c.dash then
		return false
	end
	c.dash = now() + DASH.Cooldown
	DashMotion.run(root, flat.Unit, DASH.Speed, DASH.Duration)

	CombatFX:FireAllClients("Dash", { character = model })
	return true
end

-- drop the guard when stunned / weapon gone, and re-raise it for players still holding F
RunService.Heartbeat:Connect(function()
	for key, c in cooldowns do
		local char = if key:IsA("Player") then key.Character else key
		if not char then
			continue
		end
		if char:GetAttribute("Blocking") and (stunned(char) or not char:FindFirstChild("Katana")) then
			CombatResolver.setBlocking(char, false)
		elseif c.wantsBlock and canBlock(key, char) then
			CombatResolver.setBlocking(char, true, false) -- no parry, they didn't time it
		end
	end
end)

return DefenseService
