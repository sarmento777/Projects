-- server-only hit detection, the client never tells us who it hit
-- it's a cone in front of the attacker + a raycast so you can't hit through walls

local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Debris = game:GetService("Debris")

local CombatConfig = require(ReplicatedStorage:WaitForChild("Combat"):WaitForChild("CombatConfig"))

local Hitbox = {}

local TAG = "Combatant"
local TARGET_RADIUS = 1.5 -- roughly how "thick" a character is
local MAX_HEIGHT_DIFF = 6

local function isAlive(model)
	local hum = model:FindFirstChildOfClass("Humanoid")
	return hum ~= nil and hum.Health > 0
end

local function clearPath(from, to, ignore)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = ignore
	return workspace:Raycast(from, to - from, params) == nil
end

-- only used when CombatConfig.Debug is on
local function drawDebug(cf, range)
	local p = Instance.new("Part")
	p.Anchored = true
	p.CanCollide = false
	p.CanQuery = false
	p.CanTouch = false
	p.Material = Enum.Material.ForceField
	p.Color = Color3.fromRGB(255, 60, 60)
	p.Size = Vector3.new(range * 1.4, 4, range)
	p.CFrame = cf * CFrame.new(0, 0, -range / 2)
	p.Parent = workspace
	Debris:AddItem(p, 0.25)
end

-- TODO: cone is fine for humanoid-sized stuff, big npcs would need a box check instead
function Hitbox.cone(attacker: Model, range: number, angleDeg: number, grace: number?): { Model }
	local root = attacker:FindFirstChild("HumanoidRootPart")
	if not root then return {} end
	local origin = root.Position
	local look = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z).Unit
	local maxDist = range + (grace or 0) + TARGET_RADIUS
	local halfAngle = math.rad(angleDeg / 2)

	if CombatConfig.Debug then
		drawDebug(root.CFrame, range)
	end

	local hits = {}
	for _, model in CollectionService:GetTagged(TAG) do
		if model == attacker or not model:IsA("Model") or not model:IsDescendantOf(workspace) or not isAlive(model) then
			continue
		end
		local tRoot = model:FindFirstChild("HumanoidRootPart")
		if not tRoot then
			continue
		end

		local d = tRoot.Position - origin
		local flat = Vector3.new(d.X, 0, d.Z)
		local dist = flat.Magnitude
		if dist > maxDist or math.abs(d.Y) > MAX_HEIGHT_DIFF then
			continue
		end

		-- if they're basically inside you the angle is meaningless, just count it
		local inCone = dist < 2.5 or math.acos(math.clamp(look:Dot(flat.Unit), -1, 1)) <= halfAngle
		if inCone and clearPath(origin, tRoot.Position, { attacker, model }) then
			table.insert(hits, model)
		end
	end
	return hits
end

return Hitbox
