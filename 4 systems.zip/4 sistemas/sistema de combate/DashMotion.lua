-- straight line dash, used by Q and by the iai. players run it on their own client,
-- npcs on the server. first version had MaxForce = math.huge and dashing into a
-- lantern launched you 300+ studs up lol. now it stops before solid stuff, the
-- force is capped and it can't bounce you upwards

local CollectionService = game:GetService("CollectionService")
local RunService = game:GetService("RunService")

local DashMotion = {}

local SKIN = 1.5 -- stop this far before whatever we'd hit
-- roughly an r6 body minus the legs, so curbs and small steps don't block the dash
local BOX = Vector3.new(2, 3.4, 1)
local ACCEL = 3000 -- enough to reach full speed in a frame or two
local MAX_RISE = 10 -- up speed allowed while dashing (slopes, steps). more than that is a bounce

local params = RaycastParams.new()
params.FilterType = Enum.RaycastFilterType.Exclude
params.RespectCanCollide = true

-- characters don't count, the iai goes through people and the dash just shoves them
local function ignoreList()
	local list = CollectionService:GetTagged("Combatant")
	local sheaths = workspace:FindFirstChild("Sheaths")
	if sheaths then
		table.insert(list, sheaths)
	end
	return list
end

function DashMotion.clearDistance(from: Vector3, dir: Vector3, dist: number): number
	params.FilterDescendantsInstances = ignoreList()
	local hit = workspace:Blockcast(CFrame.lookAt(from, from + dir), BOX, dir * (dist + SKIN), params)
	return hit and math.max(0, hit.Distance - SKIN) or dist
end

-- keep = how much sideways speed is left at the end (0.2 small slide, 0 dead stop)
function DashMotion.run(root: BasePart, dir: Vector3, speed: number, duration: number, keep: number?): number
	local dist = DashMotion.clearDistance(root.Position, dir, speed * duration)
	local time = dist / speed
	if time < 0.02 then
		return 0 -- already against a wall
	end

	local att = Instance.new("Attachment")
	att.Parent = root
	local lv = Instance.new("LinearVelocity")
	lv.Attachment0 = att
	lv.RelativeTo = Enum.ActuatorRelativeTo.World
	lv.VelocityConstraintMode = Enum.VelocityConstraintMode.Plane
	lv.PrimaryTangentAxis = Vector3.xAxis
	lv.SecondaryTangentAxis = Vector3.zAxis
	lv.PlaneVelocity = Vector2.new(dir.X, dir.Z) * speed
	lv.MaxForce = root.AssemblyMass * ACCEL
	lv.Parent = root

	local clamp = RunService.Heartbeat:Connect(function()
		local v = root.AssemblyLinearVelocity
		if v.Y > MAX_RISE then
			root.AssemblyLinearVelocity = Vector3.new(v.X, MAX_RISE, v.Z)
		end
	end)

	task.delay(time, function()
		clamp:Disconnect()
		lv:Destroy()
		att:Destroy()
		local k = keep or 0.2
		local v = root.AssemblyLinearVelocity
		root.AssemblyLinearVelocity = Vector3.new(v.X * k, math.min(v.Y, MAX_RISE), v.Z * k)
	end)
	return dist
end

return DashMotion
